import numpy as np
def f(h):
    arr = np.array([0, 1, 0])
    fX = arr
    return fX