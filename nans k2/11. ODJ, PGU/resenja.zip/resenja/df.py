import numpy as np
def df(h):
    arr = np.array([0, -1, 1])
    fX = arr/h
    return fX